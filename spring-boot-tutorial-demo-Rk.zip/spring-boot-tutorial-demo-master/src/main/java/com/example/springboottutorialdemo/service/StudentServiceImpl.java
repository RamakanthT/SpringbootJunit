package com.example.springboottutorialdemo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.springboottutorialdemo.entity.StudentEntity;
import com.example.springboottutorialdemo.exception.StudentNotFoundException;
import com.example.springboottutorialdemo.repository.StudentRepository;
import com.example.springboottutorialdemo.service.StudentService;

@Service
@Qualifier("stuServiceImpl1")
public class StudentServiceImpl implements StudentService {

//	@Autowired
//	private StudentRepository studentRepository;
	
	public List<StudentEntity> studentList = new ArrayList<StudentEntity>();
	public int startFlag= 0;
	
	@Override
	public StudentEntity addStudent(StudentEntity student) {
//		return studentRepository.save(student);
		studentList.add(student);
		return student;
	}

	
	@Override
	public List<StudentEntity> getAllStudent() {
//		return studentRepository.findAll();
		if(startFlag == 0) {
		StudentEntity stuObj = new StudentEntity();
		stuObj.setAddress("addr1");
		stuObj.setId(1);
		stuObj.setName("name1");
		stuObj.setRollNo(1);
		studentList.add(stuObj);
		startFlag++;
		}
		return studentList;
	}

	@Override
	public StudentEntity getStudentById(Integer id) {
				
		if(studentList != null) {
			for(StudentEntity stuObj : studentList){
				if(stuObj.getId() == id) {
					return stuObj;
				}
			}
		}
		
		throw new StudentNotFoundException("Student with id : " + id + " doesn't exist.");
	}

	@Override
	public StudentEntity updateStudentById(StudentEntity student, Integer id) {
		
		int matchedStuIndex = 0;
		
		if(studentList != null) {
			for(int i=0; i< studentList.size(); i++){
				if(studentList.get(i).getId() == id) {
					matchedStuIndex = i;
				}
			}
		}
		
		if(matchedStuIndex > 0) {
			studentList.get(matchedStuIndex).setName(student.getName());
			studentList.get(matchedStuIndex).setAddress(student.getAddress());
			studentList.get(matchedStuIndex).setRollNo(student.getRollNo());
			return studentList.get(matchedStuIndex);
			}else {
				throw new StudentNotFoundException("Student with id : " + id + " doesn't exist.");
			}
		
		
	}

	@Override
	public StudentEntity deleteStudentById(Integer id) {
		StudentEntity matchedStudentEntity = null;
		if(studentList != null) {
			for(int i=0; i< studentList.size(); i++){
				if(studentList.get(i).getId() == id) {
					matchedStudentEntity =  studentList.get(i);
					studentList.remove(i);
//					return matchedStudentEntity;
			}
		}
	}else {
		throw new StudentNotFoundException("Student with id : " + id + " doesn't exist.");
	}
		return matchedStudentEntity;
	}
	
	
	@Override
	public List<StudentEntity> getStudentByName(String name) {
		List<StudentEntity> stuList = new ArrayList<StudentEntity>();
		
		if(studentList != null) {
			for(int i=0; i< studentList.size(); i++){
				if(studentList.get(i).getName().toLowerCase().contains(name.toLowerCase())) {
					stuList.add(studentList.get(i));
			}
		}
	}
		return stuList;
	}

	

}
