package com.example.springboottutorialdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.*"})
public class SpringBootTutorialDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTutorialDemoApplication.class, args);
	}

}
