package com.example.springboottutorialdemo.repository;

import java.util.List;

import com.example.springboottutorialdemo.entity.StudentEntity;

//public interface StudentRepository extends JpaRepository<StudentEntity, Integer> {
	public interface StudentRepository {

	public List<StudentEntity> findByName(String name);
}
