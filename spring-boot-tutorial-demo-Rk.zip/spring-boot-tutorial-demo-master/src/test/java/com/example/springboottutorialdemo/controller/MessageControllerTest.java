package com.example.springboottutorialdemo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class MessageControllerTest {
	
	@Test
	public void test() {
//		fail("Not yet implemented");
		MessageController mcObj = new MessageController();
//		assertEquals(msgControllerObj.getMessage(), "Welcome to Gain Java Knowledge");
		assertEquals(mcObj.getMessage(), "Welcome to Gain Java Knowledge");
	}

}
