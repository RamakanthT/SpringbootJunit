package com.example.springboottutorialdemo.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;

class ErrorMessageTest {

	@Mock
	private HttpStatus status;
//	private String message;
	ErrorMessage emObj;
	
	@BeforeEach
	void test() {
		emObj = new ErrorMessage(status, "msg1");
	}
	
	@Test
	void testConstructor() {
		assertEquals(emObj.getMessage(), "msg1");
	}
	
	@Test
	void testSetMsg() {
		emObj.setMessage("msg1");
		assertEquals(emObj.getMessage(), "msg1");
	}

}
