package com.example.springboottutorialdemo.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class StudentEntityTest {

	StudentEntity seObj;
	
	@BeforeEach
	public void beforeStep1() {
		seObj = new StudentEntity("s1", 1, "addr1");
	}
	
	@Test
	void testConstructor() {
		assertEquals(seObj.getRollNo(), 1);
		assertEquals(seObj.getName(), "s1");
		assertEquals(seObj.getAddress(), "addr1");
//		assertEquals(seObj.getId(), 1);
	}

	@Test
	void testConstructor2() {
		seObj.setId(1);
		
		assertEquals(seObj.getRollNo(), 1);
		assertEquals(seObj.getName(), "s1");
		assertEquals(seObj.getAddress(), "addr1");
		assertEquals(seObj.getId(), 1);
	}
}
